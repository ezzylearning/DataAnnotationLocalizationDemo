﻿using DataAnnotationLocalizationDemo.Models;

namespace DataAnnotationLocalizationDemo.Services
{
    public interface ILocalizationService
    {
        StringResource GetStringResource(string resourceKey, int languageId);
    }
}
