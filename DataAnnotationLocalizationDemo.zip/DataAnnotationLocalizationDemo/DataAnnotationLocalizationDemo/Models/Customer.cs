﻿namespace DataAnnotationLocalizationDemo.Framework
{
    public class Customer
    {
        public int Id { get; set; }

        [LocalizedDisplayName("customer.page.create.firstname")]
        public string? FirstName { get; set; }

        [LocalizedDisplayName("customer.page.create.lastname")]
        public string? LastName { get; set; }
    }
}
